"use client";
import React, { createContext, useContext, useState, useCallback } from "react";

type ToastKind = "success" | "error" | "info";

type Toast = {
  id: number;
  kind: ToastKind;
  message: string;
};

type ToastContext = {
  success: (msg: string) => void;
  error: (msg: string) => void;
  info: (msg: string) => void;
};

const ToastCtx = createContext<ToastContext | null>(null);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const push = useCallback((kind: ToastKind, message: string) => {
    const id = Date.now();
    setToasts((cur) => [...cur, { id, kind, message }]);
    // auto close 2.5s
    setTimeout(() => setToasts((cur) => cur.filter((t) => t.id !== id)), 2500);
  }, []);

  const success = useCallback((m: string) => push("success", m), [push]);
  const error = useCallback((m: string) => push("error", m), [push]);
  const info = useCallback((m: string) => push("info", m), [push]);

  return (
    <ToastCtx.Provider value={{ success, error, info }}>
      {children}

      {/* Toast UI (floating) */}
      <div className="fixed inset-x-0 top-4 z-[60] mx-auto w-full max-w-md space-y-2 px-4">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={[
              "rounded-xl px-4 py-3 shadow-md ring-1 backdrop-blur bg-white/90",
              t.kind === "success" && "ring-green-200",
              t.kind === "error" && "ring-rose-200",
              t.kind === "info" && "ring-sky-200",
            ]
              .filter(Boolean)
              .join(" ")}
          >
            <div className="flex items-center gap-3">
              <span>
                {t.kind === "success" ? "✅" : t.kind === "error" ? "⚠️" : "ℹ️"}
              </span>
              <p className="text-sm text-slate-700">{t.message}</p>
            </div>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error("useToast must be used inside <ToastProvider />");
  return ctx;
}
