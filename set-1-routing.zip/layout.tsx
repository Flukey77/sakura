// src/app/layout.tsx
import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@/app/globals.css"; // โหลด CSS หลัก
import { ToastProvider } from "@/app/components/ToastProvider";

export const metadata: Metadata = {
  title: "Sakura",
  description: "Dashboard",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="th" suppressHydrationWarning>
      {/* ให้ root เป็นผู้กำหนดคลาสของ body ที่เดียว
         - พอเรามี bg ผ่าน globals.css อยู่แล้ว สามารถให้แค่ min-h-screen ก็พอ */}
      <body className="min-h-screen">
        <ToastProvider>
          {children}
        </ToastProvider>
      </body>
    </html>
  );
}
