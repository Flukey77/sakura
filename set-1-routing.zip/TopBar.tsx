"use client";

import { signOut } from "next-auth/react";
import { useState } from "react";

export default function TopBar() {
  const [q, setQ] = useState("");

  return (
    <header className="sticky top-0 z-40 bg-white/70 backdrop-blur border-b">
      <div className="mx-auto max-w-[1400px] px-4 sm:px-6 py-3 flex items-center gap-3">
        {/* ซ่อนชื่อบนมือถือ เหลือแต่โลโก้/ไอคอน */}
        <a href="/dashboard" className="hidden md:inline-flex font-semibold text-slate-800">
          Sakura
        </a>

        {/* ช่องค้นหา – เต็มความกว้างบนมือถือ */}
        <div className="flex-1">
          <label className="sr-only">ค้นหา</label>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ค้นหารายการ, ลูกค้า, ช่องทาง"
            className="input"
          />
        </div>

        {/* ปุ่มออกจากระบบ */}
        <button
          onClick={() => signOut({ callbackUrl: "/login" })}
          className="btn btn-outline"
          title="ออกจากระบบ"
        >
          ออกจากระบบ
        </button>
      </div>
    </header>
  );
}
