"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart2, ShoppingCart, PlusCircle, Boxes, Truck, LayoutDashboard
} from "lucide-react";

const items = [
  { href: "/dashboard", label: "ภาพรวม", icon: LayoutDashboard },
  { href: "/sales", label: "รายการขาย", icon: ShoppingCart },
  { href: "/sales/new", label: "สร้างรายการขาย", icon: PlusCircle },
  { href: "/products", label: "คลังสินค้า/สาขา", icon: Boxes },
  { href: "/shipping", label: "บริการขนส่ง", icon: Truck },
  { href: "/reports", label: "รายงาน", icon: BarChart2 },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex w-72 min-h-screen border-r bg-white">
      <div className="p-4 w-full">
        {/* Logo */}
        <div className="flex items-center gap-3 pb-4 border-b">
          <div className="h-9 w-9 rounded-xl bg-blue-600 text-white grid place-items-center font-bold">S</div>
          <span className="font-semibold text-lg">Sakura</span>
        </div>

        {/* Menus */}
        <nav className="mt-3 space-y-1">
          {items.map(({ href, label, icon: Icon }) => {
            const active = pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-3 px-3 py-2 rounded-xl text-[15px]
                  ${active ? "bg-blue-50 text-blue-700" : "text-slate-700 hover:bg-slate-50"}`}
              >
                <Icon size={18} />
                <span>{label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
}
