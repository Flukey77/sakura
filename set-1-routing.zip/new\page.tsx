"use client";

import { useState } from "react";

type Item = { code: string; name: string; qty: number; price: number; discount?: number };

export default function NewSalePage() {
  const [items, setItems] = useState<Item[]>([
    { code: "", name: "", qty: 0, price: 0, discount: 0 },
  ]);

  const totalBeforeVat = items.reduce((s, it)=> s + it.qty * it.price - (it.discount || 0), 0);
  const vat = Math.round(totalBeforeVat * 0.07 * 100) / 100;
  const grand = Math.round((totalBeforeVat + vat) * 100) / 100;

  function updateItem(i: number, patch: Partial<Item>) {
    setItems(prev => prev.map((it, idx)=> idx===i ? { ...it, ...patch } : it));
  }
  function addRow() {
    setItems(prev => [...prev, { code:"", name:"", qty:0, price:0, discount:0 }]);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">สร้างรายการขาย</h1>
        <div className="flex items-center gap-3">
          <button className="rounded-xl border px-4 py-2">บันทึก + สร้างใหม่</button>
          <button className="rounded-xl bg-blue-600 text-white px-4 py-2">บันทึก</button>
        </div>
      </div>

      {/* กล่องใหญ่ 2 คอลัมน์: ข้อมูล/ลูกค้า */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* ข้อมูลเอกสาร */}
        <div className="rounded-2xl border bg-white">
          <div className="p-5 border-b"><h2 className="font-semibold text-lg">ข้อมูล</h2></div>
          <div className="p-5 space-y-4">
            <div>
              <label className="text-sm">รายการ</label>
              <input className="input mt-1 w-full" defaultValue="SO-202510001" />
            </div>
            <div>
              <label className="text-sm">วันที่</label>
              <input type="date" className="input mt-1 w-full" />
            </div>
            <div>
              <label className="text-sm">อ้างอิง</label>
              <input className="input mt-1 w-full" placeholder="PO, ใบจอง ฯลฯ" />
            </div>
            <div>
              <label className="text-sm">ช่องทางการขาย</label>
              <select className="input mt-1 w-full">
                <option>กรุณาเลือก</option>
                <option>TikTok</option>
                <option>Facebook</option>
                <option>ตัวแทนจำหน่าย</option>
              </select>
            </div>
            <div>
              <label className="text-sm">ประเภทภาษี</label>
              <select className="input mt-1 w-full">
                <option>ไม่มีภาษี</option>
                <option>แยกภาษี</option>
                <option>รวมภาษี</option>
              </select>
            </div>
          </div>
        </div>

        {/* ลูกค้า */}
        <div className="rounded-2xl border bg-white">
          <div className="p-5 border-b"><h2 className="font-semibold text-lg">ลูกค้า</h2></div>
          <div className="p-5 space-y-4">
            <div>
              <label className="text-sm">ชื่อลูกค้า</label>
              <input className="input mt-1 w-full" placeholder="พิมพ์ ชื่อ,รหัส" />
            </div>
            <div>
              <label className="text-sm">เบอร์โทรศัพท์ลูกค้า</label>
              <input className="input mt-1 w-full" />
            </div>
            <div>
              <label className="text-sm">อีเมลลูกค้า</label>
              <input className="input mt-1 w-full" />
            </div>
            <div>
              <label className="text-sm">ที่อยู่ลูกค้า</label>
              <textarea className="input mt-1 w-full h-28" />
            </div>
          </div>
        </div>
      </div>

      {/* บล็อก: พัสดุ/จัดส่ง */}
      <div className="rounded-2xl border bg-white">
        <div className="p-5 border-b"><h2 className="font-semibold text-lg">ข้อมูลการจัดส่งสินค้า</h2></div>
        <div className="p-5 grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="text-sm">ชื่อผู้รับ</label>
              <input className="input mt-1 w-full" />
            </div>
            <div>
              <label className="text-sm">เบอร์โทรศัพท์ผู้รับ</label>
              <input className="input mt-1 w-full" />
            </div>
            <div>
              <label className="text-sm">อีเมลผู้รับ</label>
              <input className="input mt-1 w-full" />
            </div>
            <div>
              <label className="text-sm">ที่อยู่/จัดส่ง</label>
              <textarea className="input mt-1 w-full h-28" />
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="text-sm block">วันส่งสินค้า</label>
              <input type="date" className="input mt-1 w-full" />
            </div>
            <div>
              <label className="text-sm">Tracking No.</label>
              <input className="input mt-1 w-full" />
            </div>
          </div>
        </div>
      </div>

      {/* ตารางสินค้า */}
      <div className="rounded-2xl border bg-white">
        <div className="p-5 border-b flex items-center justify-between">
          <h2 className="font-semibold text-lg">สินค้า</h2>
          <button onClick={addRow} className="rounded-xl border px-3 py-1.5 hover:bg-slate-50">+ เพิ่มสินค้า</button>
        </div>
        <div className="p-2 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500 border-b">
                <th className="py-3 px-4 w-[140px]">รหัส</th>
                <th className="py-3 px-4">ชื่อสินค้า</th>
                <th className="py-3 px-4 w-[120px]">จำนวน</th>
                <th className="py-3 px-4 w-[160px]">มูลค่าต่อหน่วย</th>
                <th className="py-3 px-4 w-[140px]">ส่วนลดต่อหน่วย</th>
                <th className="py-3 px-4 w-[140px] text-right">รวม</th>
              </tr>
            </thead>
            <tbody>
              {items.map((it, i)=> {
                const line = (it.qty * it.price) - (it.discount || 0);
                return (
                  <tr key={i} className="border-t">
                    <td className="py-2 px-4">
                      <input className="input w-full" value={it.code} onChange={(e)=>updateItem(i,{code:e.target.value})}/>
                    </td>
                    <td className="py-2 px-4">
                      <input className="input w-full" value={it.name} onChange={(e)=>updateItem(i,{name:e.target.value})}/>
                    </td>
                    <td className="py-2 px-4">
                      <input type="number" className="input w-full text-right"
                        value={it.qty} onChange={(e)=>updateItem(i,{qty:Number(e.target.value)})}/>
                    </td>
                    <td className="py-2 px-4">
                      <input type="number" className="input w-full text-right"
                        value={it.price} onChange={(e)=>updateItem(i,{price:Number(e.target.value)})}/>
                    </td>
                    <td className="py-2 px-4">
                      <input type="number" className="input w-full text-right"
                        value={it.discount ?? 0} onChange={(e)=>updateItem(i,{discount:Number(e.target.value)})}/>
                    </td>
                    <td className="py-2 px-4 text-right">{line.toLocaleString("th-TH")}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* ส่วนรวมเงิน */}
        <div className="p-5 grid md:grid-cols-2 gap-6 border-t">
          <div className="space-y-4">
            <label className="text-sm">ช่องทางจัดส่ง</label>
            <select className="input w-full">
              <option>ไม่ระบุ</option>
              <option>FLASH</option>
              <option>ไปรษณีย์ไทย</option>
            </select>
            <label className="text-sm">หมายเหตุ</label>
            <textarea className="input h-28" />
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>มูลค่ารวมก่อนภาษี</div>
              <div>{totalBeforeVat.toLocaleString("th-TH", { minimumFractionDigits:2 })}</div>
            </div>
            <div className="flex items-center justify-between">
              <div>ภาษีมูลค่าเพิ่ม (7%)</div>
              <div>{vat.toLocaleString("th-TH", { minimumFractionDigits:2 })}</div>
            </div>
            <div className="mt-3 rounded-xl bg-slate-100 p-4 flex items-center justify-between font-semibold">
              <div>มูลค่ารวมสุทธิ</div>
              <div className="text-xl">{grand.toLocaleString("th-TH", { minimumFractionDigits:2 })}</div>
            </div>
          </div>
        </div>
      </div>

      {/* การชำระเงิน & คลัง */}
      <div className="rounded-2xl border bg-white">
        <div className="p-5 grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold text-lg mb-3">การชำระเงิน</h3>
            <div className="space-y-3">
              <select className="input w-full">
                <option>ไม่มี</option>
                <option>โอนบางส่วน</option>
                <option>ชำระครบ</option>
              </select>
              <button className="rounded-xl border px-3 py-2">เพิ่มการชำระเงิน</button>
            </div>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-3">คลังสินค้า/สาขา</h3>
            <div className="space-y-3">
              <label className="flex items-center gap-3">
                <input type="radio" name="wh" defaultChecked /> รอโอนสินค้า
              </label>
              <select className="input w-full">
                <option>ไม่ระบุ</option>
                <option>คลังหลัก</option>
              </select>
              <label className="flex items-center gap-3">
                <input type="radio" name="wh" /> โอนทันทีออกจากคลังสินค้า
              </label>
            </div>
          </div>
        </div>
        <div className="p-5 border-t flex items-center justify-between">
          <a href="/sales" className="text-slate-600 hover:underline">กลับ</a>
          <div className="flex items-center gap-3">
            <button className="rounded-xl border px-4 py-2">บันทึก + สร้างใหม่</button>
            <button className="rounded-xl bg-blue-600 text-white px-4 py-2">บันทึก</button>
          </div>
        </div>
      </div>
    </div>
  );
}
